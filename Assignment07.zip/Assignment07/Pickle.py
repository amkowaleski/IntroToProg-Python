#-------------------------------------------------#
# Title: Pickle
# Purpose: Creates a list of books that you've read
# Dev:   Alyssa Kowaleski
# Date:  Feburary 24, 2019
# ChangeLog: (Who, When, What)
#   akowales, 2/24/19, Created
#-------------------------------------------------#

import pickle
import os.path

# Define variables
lstBookList = []
objFile = "pickle.dat"

# If file exists, read it into a list
# Else, create the file

if os.path.exists(objFile):
    objFile = open("pickle.dat", "rb")
    lstBookList = pickle.load(objFile)
    objFile.close()
else:
    objFile = open("pickle.dat", "wb")
    objFile.close()

# Ask user to enter title and author, append it to the existing list
# Allow them to continue entering books until they enter 0
while(True):
    strInput = input("Press Enter to add a book or enter 0 to exit.")
    if strInput == "0":
        break
    else:
        strNewTitle = input("What is the title? ")
        strNewAuthor = input("Who is the author? ")
        lstNewBook = [strNewTitle,strNewAuthor]
        lstBookList += [lstNewBook]

# Overwrite the existing file with the new list
objFile = open("pickle.dat","wb+")
pickle.dump(lstBookList,objFile)
objFile.close()

# Print current list
print("Here are the books that you have read: ")
for row in lstBookList:
    print(row)
input("\n Press Enter to close.")
