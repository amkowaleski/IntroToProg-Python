#-------------------------------------------------#
# Title: TryExcept
# Dev:   Alyssa Kowaleski
# Date:  Feburary 24, 2019
# ChangeLog: (Who, When, What)
#   akowales, 2/24/19, Created
#-------------------------------------------------#

print("Let's do some math! Think of two numbers.")

# Ask user for two numbers and show them the math results
try:
    fltNumber1 = float(input("Enter the first number: ")) #Ask user to enter first number, save
    fltNumber2 = float(input("Enter the second number: ")) #Ask user to enter second number, save
    print("Addition: ",fltNumber1, "+", fltNumber2, "=",fltNumber1 + fltNumber2) # Add numbers
    print("Subtraction: ",fltNumber1, "-", fltNumber2, "=", fltNumber1 - fltNumber2) # Subtract numbers
    print("Multiplication: ",fltNumber1, "*", fltNumber2, "=", fltNumber1 * fltNumber2) # Multiply numbers
    print("Division: ",fltNumber1, "/", fltNumber2, "=", fltNumber1 / fltNumber2) # Divide numbers

# If they enter an invalid number, show them an error message
except ValueError:
    print("\nThat's not a valid number. Please try again.")

# If they enter a zero as the second number, show them in the division line that there was an error
except ZeroDivisionError:
    print("Division: Unable to divide by zero.")

# ANy other error, show a generic message
except Exception as e:
    print("\nThere was an error: ",e)

input("\nPress Enter to exit.")