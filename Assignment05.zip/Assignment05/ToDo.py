# ------------------------------------ #
# Title: ToDo
# Desc: This script will display a To Do list and allow the user to add/remove tasks.
# Change Log: (Who, When, What)
# akowales, 2019-02-09, Created File
# ------------------------------------ #

objFile = open("C:\\Users\\Alyssa\\_PythonClass\\Assignment05\\Todo.txt","r")
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

for row in objFile:
    strData = row.strip("\n")
    lstData = strData.split(",")
    dicRow = {"Task":lstData[0],"Priority":lstData[1]}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        for row in lstTable:
            print(row["Task"], ",", row["Priority"])
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strNewTask = input("What is the task? ")
        strNewPriority = input("What is the priority? ")
        dicNewItem = {"Task":strNewTask,"Priority":strNewPriority}
        lstTable.append(dicNewItem)
        print("\n---The task has been added.---")
        continue
    # Step 5 - Remove item from the list/Table
    elif(strChoice == '3'):
        for item in lstTable:
            print(lstTable.index(item),item)
        intDeleteItem = int(input("Enter the number of the item you'd like to delete: "))
        del lstTable[intDeleteItem]
        print("\n---The task has been removed.---")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFile = open("C:\\Users\\Alyssa\\_PythonClass\\Assignment05\\Todo.txt", "w")
        for row in lstTable:
            strRow = str(row["Task"] +","+ row["Priority"])
            objFile.write(strRow.strip() + "\n")
        objFile.close()
        print("\n---Your list has been saved.---")
        continue
    elif (strChoice == '5'):
        break #and Exit the program