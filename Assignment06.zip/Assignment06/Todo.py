#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   Alyssa Kowaleski, 02/14/2019, Organized into functions and classes
#-------------------------------------------------#

class AskUser:
    ''' Set of functions that will ask the user for input '''

    @staticmethod
    def AskForChoice():  # Shows user choices and gets input
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()
        return strChoice

    def AskForTask():  # Asks the user for a task
        strTask = str(input("What is the task? - ")).strip()
        return strTask

    def AskforPriority():  # Asks the user for a priority
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        return strPriority

    def AskToSaveData(): # Asks user whether or not they'd like to save data
        strSaveData = str(input("Save this data to file? (y/n) - ")).strip().lower()
        return strSaveData


class ActOnFile:
    ''' Set of functions that take action on the file '''

    @staticmethod
    def ReadFileData(FileName): # Pulls data from file and saves it to a list of dictionaries
        objFile = open(FileName, "r")
        for line in objFile:
            lstData = line.split(",")
            dicRow = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    def SaveToFile(FileName,Table): # Saves data to file
            objFile = open(FileName, "w")
            for dicRow in Table:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()

class Presentation:
    '''  Set of functions that display information to the user '''

    @staticmethod
    def PrintTasks(table): # Shows current items in table
        print("******* The current items ToDo are: *******")
        for row in table:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    def DataSaved(): # Tells user that data was saved
        input("\nData saved to file! Press the [Enter] key to return to menu.\n")

    def DataNotSaved(): # Tells user that data was not saved
        input("\nNew data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.\n")

    def ItemRemoved(): # Tells the user that the item was removed
        print("\nThe task was removed.\n")

    def ItemNotRemoved(): # Tells the user that the item was not removed
        print("\nI'm sorry, but I could not find that task.\n")


class UpdateList:
    ''' Set of functions that update the list of tasks'''

    @staticmethod
    def AddItem(Task,Priority): # Adds task to table
        dicRow = {"Task": Task, "Priority": Priority}
        lstTable.append(dicRow)
        return lstTable

    def RemoveItem(task): # Removes task from table
        blnItemRemoved = False
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (task == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        return lstTable,blnItemRemoved

# ---------------------------------------------------------------------------- #

objFileName = "C:\\users\\Alyssa\\_PythonClass\\Assignment06\\Todo.txt"
lstData = ""
dicRow = {}
lstTable = []

lstTable = ActOnFile.ReadFileData(objFileName) # Assigning the lstTable variable so that we can use it outside the function, using parameter

while(True):
    strChoice = AskUser.AskForChoice() # Showing options and getting user's choice

    # Show the current items in the table
    if (strChoice == '1'): # If choice is 1
        Presentation.PrintTasks(lstTable) # Show list of tasks
        continue # Continue to show options

    # Add a new item to the list/Table
    elif(strChoice == '2'): # If choice is 2
        strTask = AskUser.AskForTask() # Ask the user for task and save to variable
        strPriority = AskUser.AskforPriority() # Ask the user for priority and save to variable
        UpdateList.AddItem(strTask,strPriority) # Add task/priority to the list
        Presentation.PrintTasks(lstTable) # Show the current list
        continue # Continue to show options

    # Remove an item from the list/Table
    elif(strChoice == '3'): # If choice is 3
        strKeyToRemove = AskUser.AskForTask() # Ask user for task and save to variable
        lstTable,blnItemRemoved = UpdateList.RemoveItem(strKeyToRemove) # Update list to remove item
        if (blnItemRemoved == True):
           Presentation.ItemRemoved()
        else:
            Presentation.ItemNotRemoved()
        Presentation.PrintTasks(lstTable) # Show the current list
        continue # Continue to show options

    # Save tasks to the file
    elif(strChoice == '4'): # If choice is 4
        Presentation.PrintTasks(lstTable) # Show the current list
        strSaveData = AskUser.AskToSaveData() # Ask user if they want to save data
        if ("y" == strSaveData): # If yes
            ActOnFile.SaveToFile(objFileName,lstTable) # Save to file
            Presentation.DataSaved() # Tell user that data was saved
        else:
            Presentation.DataNotSaved() # Tell user that data was not saved
        continue # Continue to show options

    # Exit program
    elif (strChoice == '5'): # If choice is 5
        break # Exit program

